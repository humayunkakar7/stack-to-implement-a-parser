package a2posted;

//Name: Humayun Khan
//McGill ID: 260669410

/**
 * This static class provides the isStatement() method to parse a sequence 
 * of tokens and to decide if it forms a valid statement
 * You are provided with the helper methods isBoolean() and isAssignment().
 * 
 * - You may add other methods as you deem necessary.
 * - You may NOT add any class fields.
 */
public class LanguageParser {

    /**
     * Returns true if the given token is a boolean value, i.e.
     * if the token is "true" or "false".
     * <p>
     * DO NOT MODIFY THIS METHOD.
     */

    private static boolean isBoolean(String token) {

        return (token.equals("true") || token.equals("false"));

    }

    /**
     * Returns true if the given token is an assignment statement of the
     * type "variable=value", where the value is a non-negative integer.
     * <p>
     * DO NOT MODIFY THIS METHOD.
     */
    private static boolean isAssignment(String token) {

        // The code below uses Java regular expressions. You are NOT required to
        // understand Java regular expressions, but if you are curious, see:
        // <http://java.sun.com/javase/6/docs/api/java/util/regex/Pattern.html>
        //
        //   This method returns true iff
        //   the token matches the following structure:
        //   one or more letters (a variable), followed by
        //   an equal sign '=', followed by
        //   one or more digits.
        //   However, the variable cannot be a keyword ("if", "then", "else",
        //   "true", "false")

        if (token.matches("if=\\d+") || token.matches("then=\\d+") ||
                token.matches("else=\\d+") || token.matches("end=\\d+") ||
                token.matches("true=\\d+") || token.matches("false=\\d+"))
            return false;
        else
            return token.matches("[a-zA-Z]+=\\d+");

    }

    /**
     * Given a sequence of tokens through a StringSplitter object,
     * this method returns true if the tokens can be parsed according
     * to the rules of the language as specified in the assignment.
     */

    public static boolean isStatement(StringSplitter splitter) {

        StringStack stack = new StringStack();
        int count = splitter.countTokens();
        String token;

        if (count == 0)
            return false;

        //   ADD YOUR CODE HERE
        token = splitter.nextToken();
        stack.push(token);
        if(count ==1 && isAssignment(token)== true){
            return true;
        }

        for (int i = 1; i <= count; i++) {
            token = splitter.nextToken();
            //stack.push(token);
            if (!token.equals("end")) {
                stack.push(token);
            }

            else {
                int counter = 0;
                while (true) {
                    String s = stack.pop();
                    if (counter == 0) {

                        if (!isAssignment(s)) {
                            return false;

                        }
                    }
                    else if (counter == 1) {
                        if (!s.equals("else")) {
                            return false;
                        }
                    }
                    else if (counter == 2) {
                        if (!isAssignment(s)) {
                            return false;

                            }
                    }
                    else if (counter == 3) {
                        if (!s.equals("then")) {
                            return false;
                        }
                    }
                    else if (counter == 4) {
                        if (!isBoolean(s)) {
                            return false;
                        }
                    }
                    else if (counter == 5) {
                        if (!s.equals("if")) {
                            return false;
                        }

                    }

                    counter++;



                    if (s.equals("if")) {
                        stack.push("a=2");
                        break;
                    }

                }
            }

        }
        if(isAssignment(stack.peek())){
            stack.pop();
        }
        return stack.isEmpty();
    }

}